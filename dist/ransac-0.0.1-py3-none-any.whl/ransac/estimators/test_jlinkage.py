import unittest

import numpy as np

from ransac.estimators import jlinkage


class TestJLinkage(unittest.TestCase):

    def test_merge_step(self):
        # lowest Jd are merged
        # tables are updated correctly
        pass

    def test_build_preference_set(self):
        pass

    def test_jaccard_distance(self):
        pass


class TestJDistTable(unittest.TestCase):

    def setUp(self):
        self.item_a = 'a'
        self.item_b = 'b'
        self.item_c = 'c'
        self.item_d = 'd'

    def test_happy(self):
        self.item_to_set_mask = {
            self.item_a: [True, True, True, True],
            self.item_b: [False, False, False, False],
            self.item_c: [True, True, False, False],
            self.item_d: [True, True, True, False]}
        table = jlinkage.JDistTable(self.item_to_set_mask)
        self.assertEqual(
            table.get_nearest_pair(),
            (frozenset({self.item_c, self.item_d}), 0.1))
        self.assertEqual(table.get_dist(self.item_c, self.item_d), 0.1)
        self.assertEqual(table.get_dist(self.item_a, self.item_b), 1)

    def test_empty(self):
        table = jlinkage.JDistTable({})
        self.assertEqual(table.get_nearest_pair(), (None, None))

    def test_disjoint(self):
        item_to_set_mask = {
            self.item_a: [True, True, True, True],
            self.item_b: [False, False, False, False]}
        table = jlinkage.JDistTable(item_to_set_mask)
        self.assertEqual(table.get_dist(self.item_a, self.item_b), 1)
        self.assertEqual(
            table.get_nearest_pair(), (frozenset({self.item_a, self.item_b}), 1))

    def test_same_set(self):
        item_to_set_mask = {
            self.item_a: [True, True, True, True],
            self.item_b: [True, True, True, True]}
        table = jlinkage.JDistTable(item_to_set_mask)
        self.assertEqual(table.get_dist(self.item_a, self.item_b), 1)
        self.assertEqual(
            table.get_nearest_pair(), (frozenset({self.item_a, self.item_b}), 1))

    def test_add_item(self):
        table = jlinkage.JDistTable({})
        self.assertEqual(table.get_nearest_pair(), (None, None))
        table.add_item(self.item_a, [True])
        self.assertEqual(table.get_nearest_pair(), (None, None))
        table.add_item(self.item_b, [False])
        self.assertEqual(
            table.get_nearest_pair(),
            (frozenset({self.item_a, self.item_b}), 1))
        table.add_item(self.item_c, [True])
        self.assertEqual(
            table.get_nearest_pair(),
            (frozenset({self.item_a, self.item_c}), 0))
        self.assertEqual(
            table.get_all_items(),
            frozenset([self.item_a, self.item_b, self.item_c]))

    def test_remove_item(self):
        item_to_set_mask = {
            self.item_a: [True],
            self.item_b: [False],
            self.item_c: [True]}
        table = jlinkage.JDistTable(item_to_set_mask)
        self.assertEqual(
            table.get_nearest_pair(),
            (frozenset({self.item_a, self.item_c}), 0))
        table.remove_item(self.item_c)
        self.assertEqual(
            table.get_nearest_pair(),
            (frozenset({self.item_a, self.item_b}), 1))
        self.assertEqual(
            table.get_all_items(),
            frozenset([self.item_a, self.item_b]))

    def test_jaccard_dist(self):

        self.assertEqual(
            jlinkage.JDistTable._jaccard_distance([True], [False]),
            0)
        self.assertEqual(
            jlinkage.JDistTable._jaccard_distance([True], [True]),
            1)
        self.assertEqual(
            jlinkage.JDistTable._jaccard_distance([True, True], [True, False]),
            0.5)
