import itertools

import numpy as np

from ransac.estimators import ransac
from ransac.estimators import xransac


class JLinkage(ransac.Ransac):
    """Runs J Linkage clustering over RANSAC hypotheses.

    This can fit multiple models, and the number of models does
    not need to be specified in advance.

    J-linkage uses agglomerative clustering based on Jaccard distance
    (a measure of Set distance). Data points are grouped based on
    how many model hypotheses they shared inlier status in.

    A final model fitting is performed on the final clusters.
    """

    def run(self, data):
        """Runs J-Linkage.

        Args:
            data: Numpy array of data points.

        Returns:
            MultiRansacResult instance with get_model_results() and
            get_global_outliers() methods.
        """
        self._validate_args(data)

        # This essentially runs RANSAC without picking a winner.
        models = list(self._generate_ransac_samples(data))

        result = xransac.MultiRansacResult()
        return result

    def _foo(self, data, models):
        cluster_to_preference_set = self._initialize_clusters(data, models)
        # get 2 clusters (a, b) with lowest j dist
        # merge(a, b)
        # repeat until lowest j dist = 1

    def _initialize_clusters(self, data, models):
        """Builds initial clusters for j-linkage.

        Args:
            data: Numpy array of data points.
            models: List of RansacHypothesis instances.

        Returns:
            Dict of cluster to preference set. A cluster is a
                set of data points. A preference set is a mask
                for models which selects models preferred by that
                cluster.
        """
        cluster_to_preference_set = {}
        for p in data:
            cluster_to_preference_set[frozenset(p)] = np.array([
                p in m.inliers for m in models])
        return cluster_to_preference_set

    def _merge_clusters(self, cluster_to_preference_set, jdist_table, cluster_a, cluster_b):
        """Merges two clusters in the cluster table.

        Args:
            cluster_to_preference_set: Dict of cluster set to preference set array.
            cluster_a: Set, any key from the table.
            cluster_b: Set, another key from the table.
        """
        preference_set_a = cluster_to_preference_set[cluster_a]
        del cluster_to_preference_set[cluster_a]
        preference_set_b = cluster_to_preference_set[cluster_b]
        del cluster_to_preference_set[cluster_b]
        cluster_to_preference_set[cluster_a.union(cluster_b)] = (
            preference_set_a & preference_set_b)

        # TODO(Rob): shrinking table
        # keep pairwise distance, access by element to all member pairs. select by smallest distance.
        # exhaustive search for 2 smallest is good enough for now. alt: kd tree. alt: cache smallest by elem, invalidate selectively
        # jdist_table[cluster_a]
        # Delete from jdist table?
        best_pair = None
        best_dist = None
        for cluster_a, cluster_b in itertools.combinations(
                cluster_to_preference_set.keys(), 2):
            pair = frozenset({cluster_a, cluster_b})
            dist = jdist_table[pair]
            if best_pair is None or dist < best_dist:
                best_pair = pair
                best_dist = dist
        best_candidates = None, None
        return best_candidates


class JDistTable(object):
    """Associates items by Jaccard distance."""

    def __init__(self, item_to_set_mask):
        """"Constructor.

        Args:
            item_to_set_mask: Dict of item to set mask. The set masks
                determine an item's distance to other items.
        """
        self._item_to_set_mask = item_to_set_mask
        # Maps pairs of items to Jaccard distance based on associated set masks.
        self._jdist_table = self._init_j_dist_table(item_to_set_mask)

    def get_dist(self, item_a, item_b):
        """Returns Jaccard distance between two items."""
        return self._jdist_table[frozenset({item_a, item_b})]

    def add_item(self, item, set_mask):
        """Adds an item to the table."""
        for other_item, other_set_mask in self._item_to_set_mask.items():
            self._jdist_table[frozenset({item, other_item})] = (
                self._jaccard_distance(set_mask, other_set_mask))
        self._item_to_set_mask[item] = set_mask

    def remove_item(self, item):
        """Removes an item from the table."""
        for other_item, other_set_mask in self._item_to_set_mask.items():
            del self._jdist_table[frozenset({item, other_item})]
        del self._item_to_set_mask[item]

    def get_nearest_pair(self):
        """Finds the nearest pair of items.

        Returns:
            Tuple of (frozenset - best pair, float, 0-1 - Jaccard distance).
            dist 0 means identical sets, dist 1 means disjoint sets.
            Both may be None if the table has fewer than 2 items.
        """
        best_pair = None
        best_dist = None
        for item_a, item_b in itertools.combinations(
                self._item_to_set_mask.keys(), 2):
            dist = self.get_dist(item_a, item_b)
            if best_pair is None or dist < best_dist:
                best_pair = frozenset({item_a, item_b})
                best_dist = dist
        return best_pair, best_dist

    def get_all_items(self):
        """Returns all items."""
        return frozenset(self._item_to_set_mask.keys())

    def _init_j_dist_table(self, item_to_set_mask):
        dist_table = {}
        for item_a, item_b in itertools.combinations(
                item_to_set_mask.keys(), 2):
            j_dist = JDistTable._jaccard_distance(
                item_to_set_mask[item_a],
                item_to_set_mask[item_b])
            dist_table[frozenset({item_a, item_b})] = j_dist
        return dist_table

    @staticmethod
    def _jaccard_distance(mask_a, mask_b):
        """Calculates Jaccard distance.

        Args:
            mask_a: Array of bools, a mask that selects the first set.
            mask_a: Array of bools, a mask that selects the second set.

        Returns:
            Float from 0-1, with 0=identical sets, 1=disjoint sets.
        """
        union_len = len(mask_a[mask_a | mask_b])
        intersect_len = len(mask_a[mask_a & mask_b])
        return float(union_len - intersect_len) / union_len


def j_linkage(data):
    # Run ransac
    # Build Preference Set matrix:
    #   -> build a len(data) x len(models hypos) matrix
    #   -> set each value to bool, whether the point fit the model (for some threshold)
    # The Consensus Set of a model hypo is the set of points that fit the model
    # The Preference Set of a point is the set of model hypotheses it fits.

    # Use Jaccard distance (a measure of set similarity, 0=identical, 1=disjoint).
    #   let Ulen = len(PS(p0).union(PS(p1)), Ilen = len(PS(p0).intersect(PS(p1)))
    #   -> J(p0, p1) = (Ulen - Ilen) / Ulen
    # We obtain n(n-1)/2 Jaccard distances.

    # Starting with len(data) sets of one point each, successively merge the
    # two clusters with smallest J distance.
    # Update Preference Set for this new cluster.
    # Update Jaccard distance table for this new cluster.
    # Repeat until the lowest J distance is 1.
    pass
