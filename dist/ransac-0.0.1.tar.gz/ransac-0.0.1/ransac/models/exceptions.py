

class DegenerateModelException(Exception):
    """Can be raised if Model.fit fails."""
    pass
